import { graphUrl } from "configs/public_url";
import axios from "axios";
import Swal from "sweetalert2";


const showConfirmationDialog = async () => {
  try {
    const result = await Swal.fire({
      title: 'Are you sure to send your question?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    });

    return result.isConfirmed;
  } catch (error) {
    console.error(error);
    return false;
  }
};

export const GetCollabQuery = async (withNotif = true) => {
  let headers = {
    'Content-Type': 'application/json',
  };

  let queryData = JSON.stringify({
    query: `query NewQuery {
            allKategoriGetCollab(first: 999) {
              edges {
                node {
                  id
                  kategoriGetCollabId
                  name
                }
              }
            }
          }`,
    variables: {},
  });

  return await axios({
    url: graphUrl,
    method: 'POST',
    headers,
    data: queryData
  })

    .then((res) => {
      return { status: res.status, ...res.data };
    })
    .catch((error) => {
      if (withNotif) {
        Swal.fire('Gagal !', (error.response && error.response.data && error.response.data.message) ? error.response.data.message : error.toString(), 'error')
        return []
      }
      console.log(error);
    });
};



export const FormGetCollabQuery = async (withNotif = true) => {
  let headers = {
    "Content-Type": "application/json",
  };

  let queryData = JSON.stringify({
    query: `query NewQuery {
      allGetCollab(first: 999) {
        edges {
          node {
            id
            applicant {
              nama
              email
              keteranganUser
            }
            kategoriGetCollab {
              edges {
                node {
                  id
                  kategoriGetCollabId
                  name
                }
              }
            }
          }
        }
      }
    }`,
    variables: {},
  });

  return await axios({
    url: graphUrl,
    method: "POST",
    headers,
    data: queryData,
  })
    .then((res) => {
      return { status: res.status, ...res.data };
    })
    .catch((error) => {
      if (withNotif) {
        Swal.fire('Gagal !', (error.response && error.response.data && error.response.data.message) ? error.response.data.message : error.toString(), 'error')
        return [];
      }
      console.log(error);
    });
};

export const AddCollab = async (withNotif = true, category = 0, description = "", name = "", email = "") => {
  let headers = {
    "Content-Type": "application/json",
  };

  let queryData = JSON.stringify({
    category: category,
    name: name,
    description: description,
    email: email
  });

  try {
    const confirmed = await showConfirmationDialog();
    if (!confirmed) {
      return[];
    }

  return await axios({
    url: "https://dev.inovasi360.id/core-service/v1/get-collab",
    method: "POST",
    headers,
    data: queryData,
  })
    .then((res) => {
      Swal.fire('Success !', 'Thank you for your interest and ask anything you want to know then we’ll reach you as soon as possible', 'success')
      return { status: res.status, ...res.data };
    })
    .catch((error) => {
      if (withNotif) {
        Swal.fire('Gagal !', (error.response && error.response.data && error.response.data.message) ? error.response.data.message : error.toString(), 'error')
        return [];
      }
      console.log(error);
    });
} catch (error) {
  console.log(error);
  return[];
}
};