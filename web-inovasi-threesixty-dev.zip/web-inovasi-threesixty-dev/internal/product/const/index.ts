export const productContent = {
  title: "Crafting creativity.",
  subtitle:
    "We learn, we craft, and we build. We are super aware on build the best experience for user can achieve.",
};

export const productList = [
  {
    title: "Be a better a Muslims with Dzikra App, your good habit builder.",
    description: "Dzikra App",
  },
  {
    title: "Explore and gain knowledge more and more with Dimulai.id",
    description: "Dimulai.id",
  },
  {
    title: "Be a better a Muslims with Dzikra App, your good habit builder.",
    description: "Dzikra App",
  },
  {
    title: "Be a better a Muslims with Dzikra App, your good habit builder.",
    description: "Dzikra App",
  },
];
