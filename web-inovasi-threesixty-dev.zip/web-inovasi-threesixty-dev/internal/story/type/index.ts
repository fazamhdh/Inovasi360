export type StoryType = {
  id: string;
  image: string;
  title: string;
  content: string;
  isHeadline?: boolean;
};
