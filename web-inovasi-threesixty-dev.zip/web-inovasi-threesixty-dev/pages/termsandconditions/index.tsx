import Header from "@commons/Header";
import Layout from "@commons/Layout";
import styles from "./TermsAndConditions.module.scss";
import { useEffect, useState } from "react";
import React from "react";
import { getTermsAndConditionsQuery } from "query/TermsAndConditionQuery";
import { Row, Col } from "antd";
import _ from "lodash";

const TermsAndConditions = () => {
  const [isJudul, setJudul] = useState("");
  const [isSubJudul, setSubJudul] = useState("");
  const [isContent, setContent] = useState("");

  const allTermAndCondition = async () => {
    const response = await getTermsAndConditionsQuery();
    if (response.data) {
      const termAndConditions = response.data.allTermsAndConditions.edges.filter((edges: any) => {
        let getAksiTerapkan = edges?.node?.termsAndConditions.aksiTerapkan
        if (getAksiTerapkan !== null) {
          if (getAksiTerapkan == 'Terapkan') {
            return true
          }
        }
      });
      const termAndConditionTerapkan = termAndConditions[0].node.termsAndConditions;
      setJudul(termAndConditionTerapkan.judul);
      setSubJudul(termAndConditionTerapkan.subJudul);
      setContent(termAndConditionTerapkan.content);
    }
  };

  useEffect(() => {
    allTermAndCondition();
  }, []);

  const formatContentWithPTags = (content: string) => {
    return content
      .split("\n")
      .map((line, index) => `<p key=${index}>${line}</p>`)
      .join("");
  };

  return (
    <Layout navbarColor="light">
      <div className={styles.termAndCondition}>
        <Header
        title={isJudul}
        subtitle={isSubJudul}
        />
        <Row>
          <Col span={24}>
            <div className={styles.content} dangerouslySetInnerHTML={{ __html: formatContentWithPTags(isContent) }} />
          </Col>
        </Row>
      </div>
    </Layout>
  );
};

export default TermsAndConditions;
