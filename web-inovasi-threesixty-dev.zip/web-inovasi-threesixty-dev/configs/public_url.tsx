export const graphUrl = "https://dev.cms.inovasi360.id/graphql";
